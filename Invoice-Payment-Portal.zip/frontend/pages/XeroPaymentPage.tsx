import { ArrowRight, CreditCard, ShieldCheck } from 'lucide-react'
import { Button } from '../lib/shadcn/button'
import { Card, CardContent } from '../lib/shadcn/card'

const xeroPaymentUrl =
  'https://in.xero.com/u6qMfmtgCDdoDxDPxu4zxdlOSbIFsdHXaDbN3UOV?utm_source=paymentLinkList'

const highlights = [
  {
    icon: ShieldCheck,
    title: 'Secure checkout',
    description: 'Payments are completed through Crezco in a protected flow.',
  },
  {
    icon: CreditCard,
    title: 'Fast completion',
    description: 'Open the payment link and complete the invoice payment in a few steps.',
  },
] as const

export default function XeroPaymentPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="mx-auto flex min-h-screen max-w-6xl items-center px-4 py-10 sm:px-6 lg:px-8">
        <Card className="w-full overflow-hidden border-border bg-card shadow-retool-md">
          <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
            <div className="bg-foreground px-8 py-10 text-background sm:px-10 lg:px-12">
              <div className="inline-flex items-center rounded-full border border-background/20 bg-background/10 px-3 py-1 text-xs font-medium uppercase tracking-[0.2em] text-background/80">
                Client payment page
              </div>

              <div className="mt-6 flex items-center gap-4">
                <div className="flex h-20 w-20 items-center justify-center rounded-full border-4 border-background text-3xl font-black tracking-tight">
                  ZM
                </div>
                <div className="space-y-1">
                  <p className="text-4xl font-black tracking-[0.24em] sm:text-5xl">ZAF</p>
                  <p className="text-lg font-semibold tracking-[0.28em] text-background/80 sm:text-xl">
                    MOTORS LTD
                  </p>
                </div>
              </div>

              <div className="mt-10 space-y-5">
                <p className="text-sm uppercase tracking-[0.3em] text-background/70">
                  Secure payment portal
                </p>
                <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">
                  Pay your invoice online
                </h1>
                <p className="max-w-md text-base text-background/80">
                  This page is designed for clients opening a direct payment link. No account or app login is needed once the app is published publicly.
                </p>
              </div>

              <div className="mt-8 grid gap-4">
                {highlights.map(({ icon: Icon, title, description }) => (
                  <div
                    key={title}
                    className="flex items-start gap-3 rounded-lg border border-background/15 bg-background/10 p-4"
                  >
                    <Icon className="mt-0.5 h-5 w-5 shrink-0 text-background" />
                    <div>
                      <p className="text-sm font-semibold text-background">{title}</p>
                      <p className="mt-1 text-sm text-background/75">{description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <CardContent className="flex flex-col justify-center gap-6 px-8 py-10 sm:px-10 lg:px-12">
              <div className="space-y-2">
                <p className="text-sm font-medium uppercase tracking-[0.24em] text-muted-foreground">
                  ZAF MOTORS
                </p>
                <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">
                  Complete your payment
                </h2>
                <p className="text-sm text-muted-foreground">
                  Click the button below to open the secure payment page in a new tab.
                </p>
              </div>

              <div className="rounded-xl border border-border bg-muted/40 p-4">
                <p className="text-sm font-medium text-foreground">Ready to continue?</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Your invoice payment will be completed outside this page using the secure checkout link.
                </p>
              </div>

              <Button asChild size="lg" className="h-12 text-base">
                <a href={xeroPaymentUrl} target="_blank" rel="noreferrer">
                  Pay Secure Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>

              <div className="rounded-lg border border-border bg-muted/50 p-4">
                <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">
                  Contact
                </p>
                <p className="mt-2 text-base font-medium text-foreground">Paul Hazell</p>
              </div>
            </CardContent>
          </div>
        </Card>
      </div>
    </div>
  )
}
