import { Navigate, Route, Routes } from 'react-router-dom'
import XeroPaymentPage from './pages/XeroPaymentPage'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/pay" replace />} />
      <Route path="/pay" element={<XeroPaymentPage />} />
    </Routes>
  )
}
